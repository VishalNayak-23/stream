
import React, { useState } from 'react';
import { User } from '../types';

interface AuthProps {
  onLogin: (user: User) => void;
}

const Auth: React.FC<AuthProps> = ({ onLogin }) => {
  const [isSignup, setIsSignup] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: '', password: '' });
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const usersStr = localStorage.getItem('nebula_users');
    const users: User[] = usersStr ? JSON.parse(usersStr) : [];

    if (isSignup) {
      if (users.find(u => u.email === formData.email)) {
        setError('User already exists with this email.');
        return;
      }
      const newUser: User = {
        id: Math.random().toString(36).substr(2, 9),
        name: formData.name,
        email: formData.email,
        password: formData.password,
        avatar: `https://picsum.photos/seed/${formData.name}/100/100`
      };
      const updatedUsers = [...users, newUser];
      localStorage.setItem('nebula_users', JSON.stringify(updatedUsers));
      onLogin(newUser);
    } else {
      const user = users.find(u => u.email === formData.email && u.password === formData.password);
      if (user) {
        onLogin(user);
      } else {
        setError('Invalid email or password.');
      }
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 bg-[#0f171e]">
      <div className="w-full max-w-md bg-[#1a242f] p-10 rounded-2xl shadow-2xl border border-gray-800 space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div className="text-center">
          <h1 className="text-3xl font-black text-cyan-500 tracking-tighter">
            NEBULA<span className="text-white">STREAM</span>
          </h1>
          <p className="text-gray-400 mt-2 font-medium">{isSignup ? 'Create your account' : 'Sign in to your account'}</p>
        </div>

        {error && (
          <div className="bg-red-500/10 border border-red-500/50 p-4 rounded-xl text-red-500 text-sm text-center">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {isSignup && (
            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Name</label>
              <input 
                type="text" required
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                className="w-full bg-gray-900 border border-gray-700 text-white rounded-xl py-4 px-6 focus:ring-2 focus:ring-cyan-500 outline-none"
                placeholder="Full Name"
              />
            </div>
          )}

          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Email</label>
            <input 
              type="email" required
              value={formData.email}
              onChange={(e) => setFormData({...formData, email: e.target.value})}
              className="w-full bg-gray-900 border border-gray-700 text-white rounded-xl py-4 px-6 focus:ring-2 focus:ring-cyan-500 outline-none"
              placeholder="name@email.com"
            />
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Password</label>
            <input 
              type="password" required
              value={formData.password}
              onChange={(e) => setFormData({...formData, password: e.target.value})}
              className="w-full bg-gray-900 border border-gray-700 text-white rounded-xl py-4 px-6 focus:ring-2 focus:ring-cyan-500 outline-none"
              placeholder="••••••••"
            />
          </div>

          <button 
            type="submit"
            className="w-full bg-cyan-600 hover:bg-cyan-500 text-white py-4 rounded-xl font-black text-lg transition-all shadow-xl active:scale-95"
          >
            {isSignup ? 'Create Account' : 'Sign In'}
          </button>
        </form>

        <div className="text-center">
          <button 
            onClick={() => setIsSignup(!isSignup)}
            className="text-cyan-500 text-sm font-bold hover:underline"
          >
            {isSignup ? 'Already have an account? Sign in' : "Don't have an account? Sign up"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Auth;
