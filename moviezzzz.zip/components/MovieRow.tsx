
import React, { useRef } from 'react';
import { Content } from '../types';
import MovieCard from './MovieCard';

interface MovieRowProps {
  title: string;
  items: Content[];
  onSelect: (content: Content) => void;
  watchlist: string[];
  onToggleWatchlist: (id: string) => void;
  isTall?: boolean;
  progressMap?: Record<string, number>;
}

const MovieRow: React.FC<MovieRowProps> = ({ 
  title, 
  items, 
  onSelect, 
  watchlist, 
  onToggleWatchlist,
  isTall = false,
  progressMap
}) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const { scrollLeft, clientWidth } = scrollRef.current;
      const scrollTo = direction === 'left' 
        ? scrollLeft - clientWidth * 0.8 
        : scrollLeft + clientWidth * 0.8;
      
      scrollRef.current.scrollTo({ left: scrollTo, behavior: 'smooth' });
    }
  };

  return (
    <div className="relative px-6 md:px-12 space-y-4 group">
      <div className="flex items-center justify-between">
        <h2 className="text-xl md:text-2xl font-bold text-gray-200 tracking-tight">{title}</h2>
        <button className="text-cyan-500 text-sm font-bold hover:underline opacity-0 group-hover:opacity-100 transition-opacity">
          View All
        </button>
      </div>

      <div className="relative flex items-center">
        {/* Scroll Buttons */}
        <button 
          onClick={() => scroll('left')}
          className="absolute left-0 z-10 p-2 bg-black bg-opacity-50 hover:bg-opacity-80 rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity -ml-4"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>

        <div 
          ref={scrollRef}
          className="flex space-x-4 overflow-x-auto hide-scrollbar scroll-smooth pb-4 px-1"
        >
          {items.map(item => (
            <MovieCard 
              key={item.id} 
              content={item} 
              onSelect={onSelect}
              inWatchlist={watchlist.includes(item.id)}
              onToggleWatchlist={onToggleWatchlist}
              isTall={isTall}
              progress={progressMap?.[item.id]}
            />
          ))}
        </div>

        <button 
          onClick={() => scroll('right')}
          className="absolute right-0 z-10 p-2 bg-black bg-opacity-50 hover:bg-opacity-80 rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity -mr-4"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        </button>
      </div>
    </div>
  );
};

export default MovieRow;
