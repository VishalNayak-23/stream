
import React from 'react';
import { Content } from '../types';
import MovieCard from './MovieCard';

interface ContentGridProps {
  title: string;
  items: Content[];
  onSelect: (content: Content) => void;
  watchlist: string[];
  onToggleWatchlist: (id: string) => void;
}

const ContentGrid: React.FC<ContentGridProps> = ({ 
  title, 
  items, 
  onSelect, 
  watchlist, 
  onToggleWatchlist 
}) => {
  return (
    <div className="px-6 md:px-12 py-10 space-y-8 min-h-[60vh]">
      <div className="flex items-center space-x-4">
        <h2 className="text-3xl font-black text-white">{title}</h2>
        <span className="bg-gray-800 text-gray-500 text-sm px-3 py-1 rounded-full font-bold">
          {items.length} items
        </span>
      </div>

      {items.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-gray-500">
          <svg className="w-20 h-20 mb-4 opacity-20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
          </svg>
          <p className="text-xl font-medium">Nothing found here.</p>
          <p className="text-sm">Try exploring our other categories!</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-y-12 gap-x-6">
          {items.map(item => (
            <div key={item.id} className="flex justify-center">
              <MovieCard 
                content={item} 
                onSelect={onSelect}
                inWatchlist={watchlist.includes(item.id)}
                onToggleWatchlist={onToggleWatchlist}
                isTall
              />
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ContentGrid;
