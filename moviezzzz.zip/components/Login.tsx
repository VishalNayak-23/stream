
import React, { useState } from 'react';

interface LoginProps {
  onLogin: (name: string) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [name, setName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) {
      onLogin(name);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 bg-[#0f171e]">
      <div className="w-full max-w-md bg-[#1a242f] p-10 rounded-2xl shadow-2xl border border-gray-800 space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div className="text-center">
          <h1 className="text-3xl font-black text-cyan-500 tracking-tighter">
            NEBULA<span className="text-white">STREAM</span>
          </h1>
          <p className="text-gray-400 mt-2 font-medium">Infinite entertainment awaits.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Your Name</label>
            <input 
              type="text" 
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. John Doe"
              className="w-full bg-gray-900 border border-gray-700 text-white rounded-xl py-4 px-6 focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all placeholder-gray-600"
            />
          </div>

          <button 
            type="submit"
            className="w-full bg-cyan-600 hover:bg-cyan-500 text-white py-4 rounded-xl font-black text-lg transition-all shadow-xl hover:shadow-cyan-900/40 active:scale-95 transform"
          >
            Start Streaming
          </button>
        </form>

        <div className="text-center space-y-4 pt-4">
          <div className="relative">
            <div className="absolute inset-0 flex items-center"><span className="w-full border-t border-gray-800"></span></div>
            <div className="relative flex justify-center text-xs uppercase"><span className="bg-[#1a242f] px-2 text-gray-600 font-bold">Or pick a profile</span></div>
          </div>
          
          <div className="flex justify-center space-x-6 pt-2">
            <button onClick={() => onLogin('Alex')} className="group flex flex-col items-center space-y-2">
              <div className="w-14 h-14 bg-purple-600 rounded-xl group-hover:scale-110 transition-transform shadow-lg group-hover:ring-4 ring-purple-900/50 flex items-center justify-center text-white font-bold text-xl">A</div>
              <span className="text-xs text-gray-400 font-bold group-hover:text-white">Alex</span>
            </button>
            <button onClick={() => onLogin('Sam')} className="group flex flex-col items-center space-y-2">
              <div className="w-14 h-14 bg-orange-600 rounded-xl group-hover:scale-110 transition-transform shadow-lg group-hover:ring-4 ring-orange-900/50 flex items-center justify-center text-white font-bold text-xl">S</div>
              <span className="text-xs text-gray-400 font-bold group-hover:text-white">Sam</span>
            </button>
            <button onClick={() => onLogin('Guest')} className="group flex flex-col items-center space-y-2">
              <div className="w-14 h-14 bg-gray-700 rounded-xl group-hover:scale-110 transition-transform shadow-lg group-hover:ring-4 ring-gray-900/50 flex items-center justify-center text-white font-bold text-xl">?</div>
              <span className="text-xs text-gray-400 font-bold group-hover:text-white">Guest</span>
            </button>
          </div>
        </div>

        <p className="text-[10px] text-gray-600 text-center leading-relaxed">
          By continuing, you agree to Nebula Stream's Conditions of Use and Privacy Notice. 
          This is a demonstration project for portfolio purposes.
        </p>
      </div>
    </div>
  );
};

export default Login;
