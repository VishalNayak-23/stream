
import React, { useState } from 'react';
import { ViewState, User } from '../types';

interface NavbarProps {
  currentView: ViewState;
  onViewChange: (view: ViewState) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  user: User | null;
  onLogout: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ 
  currentView, 
  onViewChange, 
  searchQuery, 
  onSearchChange, 
  user, 
  onLogout 
}) => {
  const [isProfileOpen, setIsProfileOpen] = useState(false);

  const tabs: { id: ViewState; label: string }[] = [
    { id: 'home', label: 'Home' },
    { id: 'movies', label: 'Movies' },
    { id: 'tv-shows', label: 'TV Shows' },
    { id: 'originals', label: 'Originals' },
    { id: 'watchlist', label: 'My Watchlist' },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-[#0f171e] bg-opacity-95 backdrop-blur-md h-20 px-6 md:px-12 flex items-center justify-between border-b border-gray-800">
      <div className="flex items-center space-x-10">
        <div 
          className="text-2xl font-black text-cyan-500 cursor-pointer tracking-tighter"
          onClick={() => onViewChange('home')}
        >
          NEBULA<span className="text-white">STREAM</span>
        </div>
        
        {user && (
          <div className="hidden lg:flex items-center space-x-6">
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => onViewChange(tab.id)}
                className={`text-sm font-semibold transition-colors duration-200 ${
                  currentView === tab.id ? 'text-white border-b-2 border-cyan-500 pb-1' : 'text-gray-400 hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="flex items-center space-x-6">
        {user && (
          <div className="relative group hidden sm:block">
            <input
              type="text"
              placeholder="Search titles..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className="bg-gray-900 border border-gray-700 text-white rounded-full py-2 px-10 focus:outline-none focus:ring-2 focus:ring-cyan-500 w-48 md:w-64 transition-all duration-300 group-hover:w-80"
            />
            <svg className="absolute left-3 top-2.5 h-5 w-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>
        )}

        {user ? (
          <div className="relative">
            <button 
              onClick={() => setIsProfileOpen(!isProfileOpen)}
              className="flex items-center space-x-2 focus:outline-none p-1 rounded-md hover:bg-white/5 transition-colors"
            >
              <img src={user.avatar} alt="Profile" className="w-9 h-9 rounded-md border-2 border-cyan-500" />
              <svg className={`h-4 w-4 text-gray-400 transform transition-transform ${isProfileOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </button>

            {isProfileOpen && (
              <div 
                className="absolute right-0 mt-3 w-56 bg-[#1a242f] rounded-lg shadow-2xl border border-gray-700 py-2 overflow-hidden animate-in fade-in slide-in-from-top-2"
                onMouseLeave={() => setIsProfileOpen(false)}
              >
                <div className="px-4 py-3 border-b border-gray-700">
                  <p className="text-sm font-bold text-white">{user.name}</p>
                  <p className="text-xs text-gray-500 truncate">{user.email}</p>
                </div>
                <button className="w-full text-left px-4 py-2 text-sm text-gray-300 hover:bg-[#252d37] hover:text-white transition-colors">
                  Account Settings
                </button>
                <button 
                  onClick={() => { onViewChange('watchlist'); setIsProfileOpen(false); }}
                  className="w-full text-left px-4 py-2 text-sm text-gray-300 hover:bg-[#252d37] hover:text-white transition-colors"
                >
                  My Watchlist
                </button>
                <button 
                  onClick={onLogout}
                  className="w-full text-left px-4 py-2 text-sm text-red-400 hover:bg-[#252d37] font-semibold border-t border-gray-700 transition-colors"
                >
                  Sign Out
                </button>
              </div>
            )}
          </div>
        ) : null}
      </div>
    </nav>
  );
};

export default Navbar;
