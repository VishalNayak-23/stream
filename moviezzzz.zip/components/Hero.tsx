
import React, { useState, useEffect } from 'react';
import { Content } from '../types';

interface HeroProps {
  content: Content;
  onSelect: (content: Content) => void;
}

const Hero: React.FC<HeroProps> = ({ content, onSelect }) => {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  return (
    <div className="relative w-full h-[70vh] md:h-[85vh] overflow-hidden group">
      {/* Background Image with Gradient Overlays */}
      <div className="absolute inset-0">
        <img 
          src={content.backdrop} 
          alt={content.title}
          className={`w-full h-full object-cover transition-transform duration-[20s] ease-linear transform ${isLoaded ? 'scale-110' : 'scale-100'}`}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0f171e] via-transparent to-transparent opacity-90" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0f171e] via-transparent to-transparent" />
      </div>

      {/* Content */}
      <div className="relative h-full flex flex-col justify-center px-6 md:px-20 max-w-4xl space-y-6">
        {content.isOriginal && (
          <div className="flex items-center space-x-2">
             <span className="bg-cyan-500 text-white text-[10px] font-black px-2 py-0.5 rounded-sm uppercase tracking-wider">Nebula</span>
             <span className="text-cyan-500 text-xs font-bold uppercase tracking-[0.2em]">Original</span>
          </div>
        )}
        
        <h1 className="text-4xl md:text-7xl font-extrabold text-white tracking-tight leading-tight">
          {content.title}
        </h1>

        <div className="flex items-center space-x-4 text-sm md:text-base font-medium text-gray-300">
          <span className="text-green-500 font-bold">{content.rating} / 10</span>
          <span>{content.year}</span>
          <span>{content.duration}</span>
          <span className="border border-gray-600 px-1.5 py-0.5 rounded text-xs uppercase">4K</span>
        </div>

        <p className="text-lg text-gray-400 line-clamp-3 md:line-clamp-4 max-w-2xl leading-relaxed">
          {content.description}
        </p>

        <div className="flex items-center space-x-4 pt-4">
          <button 
            onClick={() => onSelect(content)}
            className="flex items-center space-x-2 bg-white text-black px-8 py-4 rounded-md font-bold hover:bg-gray-200 transition-all transform hover:scale-105 active:scale-95"
          >
            <svg className="w-6 h-6 fill-current" viewBox="0 0 24 24">
              <path d="M8 5v14l11-7z" />
            </svg>
            <span>Watch Now</span>
          </button>
          
          <button 
            onClick={() => onSelect(content)}
            className="flex items-center space-x-2 bg-gray-500 bg-opacity-30 backdrop-blur-md text-white px-8 py-4 rounded-md font-bold hover:bg-opacity-40 transition-all border border-gray-600"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <span>More Info</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Hero;
