
import React from 'react';
import { Content } from '../types';

interface MovieCardProps {
  content: Content;
  onSelect: (content: Content) => void;
  inWatchlist: boolean;
  onToggleWatchlist: (id: string) => void;
  isTall?: boolean;
  progress?: number;
}

const MovieCard: React.FC<MovieCardProps> = ({ 
  content, 
  onSelect, 
  inWatchlist, 
  onToggleWatchlist,
  isTall = false,
  progress
}) => {
  return (
    <div 
      className={`relative flex-none rounded-lg overflow-hidden cursor-pointer group transition-all duration-300 transform hover:scale-110 z-0 hover:z-20 shadow-lg ${
        isTall ? 'w-48 h-72' : 'w-64 h-36 md:w-80 md:h-44'
      }`}
    >
      <img 
        src={isTall ? content.thumbnail : content.backdrop} 
        alt={content.title}
        className="w-full h-full object-cover"
      />
      
      {/* Overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-4">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <h3 className="text-sm font-bold text-white line-clamp-1">{content.title}</h3>
            <div className="flex items-center space-x-2 text-[10px] text-gray-300">
              <span className="text-green-500 font-bold">{content.rating}</span>
              <span>{content.year}</span>
              <span>{content.duration}</span>
            </div>
          </div>
          <div className="flex space-x-2">
            <button 
              onClick={(e) => {
                e.stopPropagation();
                onSelect(content);
              }}
              className="bg-white rounded-full p-2 text-black hover:bg-cyan-500 hover:text-white transition-colors"
            >
              <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                <path d="M8 5v14l11-7z" />
              </svg>
            </button>
            <button 
              onClick={(e) => {
                e.stopPropagation();
                onToggleWatchlist(content.id);
              }}
              className={`rounded-full p-2 border border-white hover:bg-white hover:text-black transition-colors ${
                inWatchlist ? 'bg-white text-black' : 'text-white'
              }`}
            >
              {inWatchlist ? (
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M19 13H5v-2h14v2z" />
                </svg>
              ) : (
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Progress Bar (Continue Watching) */}
      {progress !== undefined && (
        <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-800">
          <div 
            className="h-full bg-cyan-500 transition-all duration-500" 
            style={{ width: `${progress}%` }} 
          />
        </div>
      )}

      {/* Label Tags */}
      <div className="absolute top-2 left-2 flex flex-col space-y-1">
        {content.isOriginal && (
          <span className="bg-cyan-600 text-white text-[8px] font-black px-1.5 py-0.5 rounded uppercase self-start">Original</span>
        )}
      </div>
    </div>
  );
};

export default MovieCard;
