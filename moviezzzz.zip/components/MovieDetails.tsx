
import React, { useState } from 'react';
import { Content } from '../types';

interface MovieDetailsProps {
  content: Content;
  onClose: () => void;
  onPlay: () => void;
  inWatchlist: boolean;
  onToggleWatchlist: () => void;
}

const MovieDetails: React.FC<MovieDetailsProps> = ({ 
  content, 
  onClose, 
  onPlay, 
  inWatchlist, 
  onToggleWatchlist 
}) => {
  const [isPlaying, setIsPlaying] = useState(false);

  const handlePlayClick = () => {
    setIsPlaying(true);
    onPlay();
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 md:p-8 animate-in fade-in duration-300">
      <div 
        className="absolute inset-0 bg-black bg-opacity-90 backdrop-blur-sm"
        onClick={onClose}
      />
      
      <div className="relative bg-[#1a242f] w-full max-w-6xl max-h-[90vh] rounded-2xl overflow-hidden shadow-2xl flex flex-col md:flex-row animate-in zoom-in-95 duration-300">
        {/* Left Side / Player Section */}
        <div className="relative w-full md:w-2/3 bg-black flex items-center justify-center group overflow-hidden">
          {isPlaying ? (
            <div className="w-full h-full aspect-video">
              <iframe 
                className="w-full h-full"
                src={`${content.trailerUrl}?autoplay=1`}
                title={content.title}
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>
          ) : (
            <>
              <img 
                src={content.backdrop} 
                className="w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-700"
                alt={content.title}
              />
              <button 
                onClick={handlePlayClick}
                className="absolute p-6 bg-cyan-600 rounded-full text-white transform hover:scale-110 transition-all shadow-xl group-hover:bg-cyan-500"
              >
                <svg className="w-10 h-10 fill-current" viewBox="0 0 24 24">
                  <path d="M8 5v14l11-7z" />
                </svg>
              </button>
              <div className="absolute bottom-6 left-6 flex items-center space-x-3">
                <span className="bg-black bg-opacity-70 text-white text-xs font-bold px-3 py-1 rounded-full border border-gray-600">WATCH TRAILER</span>
              </div>
            </>
          )}
        </div>

        {/* Right Side / Info Section */}
        <div className="w-full md:w-1/3 p-6 md:p-10 flex flex-col justify-between overflow-y-auto bg-gradient-to-b from-[#1a242f] to-[#0f171e]">
          <button 
            onClick={onClose}
            className="absolute top-6 right-6 text-gray-400 hover:text-white transition-colors"
          >
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>

          <div className="space-y-6">
            <h2 className="text-3xl md:text-4xl font-black text-white leading-tight">{content.title}</h2>
            
            <div className="flex flex-wrap gap-2">
              {content.genres.map(genre => (
                <span key={genre} className="text-[10px] md:text-xs font-bold px-3 py-1 bg-gray-800 rounded-full text-gray-400 border border-gray-700">
                  {genre}
                </span>
              ))}
            </div>

            <div className="flex items-center space-x-4 text-sm text-gray-400">
              <span className="text-green-500 font-black">{content.rating} / 10</span>
              <span>{content.year}</span>
              <span>{content.duration}</span>
            </div>

            <p className="text-gray-300 leading-relaxed text-sm md:text-base italic">
              "{content.description}"
            </p>

            <div className="space-y-2">
              <h4 className="text-xs font-black text-gray-500 uppercase tracking-widest">Starring</h4>
              <p className="text-sm text-gray-300">{content.cast.join(', ')}</p>
            </div>
          </div>

          <div className="flex flex-col space-y-3 mt-10">
            <button 
              onClick={handlePlayClick}
              className="w-full bg-cyan-600 hover:bg-cyan-500 text-white py-4 rounded-xl font-black text-lg transition-all shadow-lg active:scale-95"
            >
              Play Now
            </button>
            <button 
              onClick={onToggleWatchlist}
              className={`w-full py-4 rounded-xl font-bold flex items-center justify-center space-x-2 border transition-all ${
                inWatchlist 
                  ? 'bg-transparent border-red-500 text-red-500 hover:bg-red-500 hover:text-white' 
                  : 'bg-white bg-opacity-10 border-gray-600 text-white hover:bg-white hover:text-black'
              }`}
            >
              {inWatchlist ? (
                <>
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                  </svg>
                  <span>Remove from Watchlist</span>
                </>
              ) : (
                <>
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                  </svg>
                  <span>Add to Watchlist</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MovieDetails;
