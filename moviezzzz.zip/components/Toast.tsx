
import React, { useEffect } from 'react';
import { Toast as ToastType } from '../types';

interface ToastProps {
  toasts: ToastType[];
  removeToast: (id: string) => void;
}

const Toast: React.FC<ToastProps> = ({ toasts, removeToast }) => {
  return (
    <div className="fixed bottom-8 right-8 z-[100] flex flex-col space-y-3">
      {toasts.map((toast) => (
        <ToastItem key={toast.id} toast={toast} onRemove={() => removeToast(toast.id)} />
      ))}
    </div>
  );
};

const ToastItem: React.FC<{ toast: ToastType; onRemove: () => void }> = ({ toast, onRemove }) => {
  useEffect(() => {
    const timer = setTimeout(onRemove, 3000);
    return () => clearTimeout(timer);
  }, [onRemove]);

  const bgClass = {
    success: 'bg-green-600',
    info: 'bg-cyan-600',
    error: 'bg-red-600',
  }[toast.type];

  return (
    <div className={`${bgClass} text-white px-6 py-3 rounded-lg shadow-2xl flex items-center space-x-3 animate-in slide-in-from-right-full duration-300`}>
      <span className="font-bold text-sm">{toast.message}</span>
      <button onClick={onRemove} className="text-white/70 hover:text-white">
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
        </svg>
      </button>
    </div>
  );
};

export default Toast;
