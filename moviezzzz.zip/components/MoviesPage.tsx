
import React, { useState, useMemo } from 'react';
import { Content } from '../types';
import MovieCard from './MovieCard';

interface MoviesPageProps {
  items: Content[];
  onSelect: (content: Content) => void;
  watchlist: string[];
  onToggleWatchlist: (id: string) => void;
}

const MoviesPage: React.FC<MoviesPageProps> = ({ items, onSelect, watchlist, onToggleWatchlist }) => {
  const [genreFilter, setGenreFilter] = useState('All');
  const [sortOption, setSortOption] = useState('newest');
  const [minRating, setMinRating] = useState(0);

  const genres = ['All', ...Array.from(new Set(items.flatMap(i => i.genres)))];

  const filteredAndSorted = useMemo(() => {
    let result = items.filter(i => i.type === 'movie');
    
    if (genreFilter !== 'All') {
      result = result.filter(i => i.genres.includes(genreFilter));
    }

    result = result.filter(i => i.rating >= minRating);

    result.sort((a, b) => {
      if (sortOption === 'newest') return b.year - a.year;
      if (sortOption === 'rating') return b.rating - a.rating;
      if (sortOption === 'alpha') return a.title.localeCompare(b.title);
      return 0;
    });

    return result;
  }, [items, genreFilter, sortOption, minRating]);

  return (
    <div className="px-6 md:px-12 py-10 space-y-8 min-h-screen">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-gray-800 pb-8">
        <div>
          <h1 className="text-4xl font-black text-white mb-2">Movies</h1>
          <p className="text-gray-400">Discover your next cinematic masterpiece.</p>
        </div>

        <div className="flex flex-wrap items-center gap-4">
          <div className="space-y-1">
            <label className="text-[10px] font-bold text-gray-500 uppercase">Genre</label>
            <select 
              value={genreFilter}
              onChange={(e) => setGenreFilter(e.target.value)}
              className="bg-[#1a242f] text-white border border-gray-700 rounded-lg px-4 py-2 text-sm focus:ring-2 focus:ring-cyan-500 outline-none block"
            >
              {genres.map(g => <option key={g} value={g}>{g}</option>)}
            </select>
          </div>

          <div className="space-y-1">
            <label className="text-[10px] font-bold text-gray-500 uppercase">Min Rating</label>
            <select 
              value={minRating}
              onChange={(e) => setMinRating(parseFloat(e.target.value))}
              className="bg-[#1a242f] text-white border border-gray-700 rounded-lg px-4 py-2 text-sm focus:ring-2 focus:ring-cyan-500 outline-none block"
            >
              <option value="0">All Ratings</option>
              <option value="7">7+ Good</option>
              <option value="8">8+ Great</option>
              <option value="9">9+ Elite</option>
            </select>
          </div>

          <div className="space-y-1">
            <label className="text-[10px] font-bold text-gray-500 uppercase">Sort By</label>
            <select 
              value={sortOption}
              onChange={(e) => setSortOption(e.target.value)}
              className="bg-[#1a242f] text-white border border-gray-700 rounded-lg px-4 py-2 text-sm focus:ring-2 focus:ring-cyan-500 outline-none block"
            >
              <option value="newest">Release Date</option>
              <option value="rating">Top Rated</option>
              <option value="alpha">A-Z</option>
            </select>
          </div>
        </div>
      </div>

      {filteredAndSorted.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-gray-500">
          <p className="text-xl font-medium">No movies match your filters.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-y-12 gap-x-6">
          {filteredAndSorted.map(item => (
            <div key={item.id} className="flex justify-center">
              <MovieCard 
                content={item} 
                onSelect={onSelect}
                inWatchlist={watchlist.includes(item.id)}
                onToggleWatchlist={onToggleWatchlist}
                isTall
              />
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default MoviesPage;
