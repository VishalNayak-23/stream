
import React, { useState, useEffect, useRef } from 'react';
import { Content } from '../types';

interface VideoPlayerProps {
  content: Content;
  onClose: () => void;
  initialProgress?: number;
  onProgressUpdate: (progress: number) => void;
}

const VideoPlayer: React.FC<VideoPlayerProps> = ({ content, onClose, initialProgress = 0, onProgressUpdate }) => {
  const [isPlaying, setIsPlaying] = useState(true);
  const [progress, setProgress] = useState(initialProgress);
  const [volume, setVolume] = useState(80);
  const [showControls, setShowControls] = useState(true);
  const controlsTimeout = useRef<number | null>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      if (isPlaying) {
        setProgress(prev => {
          const next = Math.min(prev + 0.1, 100);
          if (next % 5 < 0.1) onProgressUpdate(next);
          return next;
        });
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [isPlaying, onProgressUpdate]);

  const handleMouseMove = () => {
    setShowControls(true);
    if (controlsTimeout.current) clearTimeout(controlsTimeout.current);
    controlsTimeout.current = window.setTimeout(() => setShowControls(false), 3000);
  };

  return (
    <div 
      className="fixed inset-0 z-[100] bg-black flex items-center justify-center cursor-none"
      onMouseMove={handleMouseMove}
      style={{ cursor: showControls ? 'default' : 'none' }}
    >
      {/* Mock Video Stream */}
      <div className="absolute inset-0 flex items-center justify-center">
        <img 
          src={content.backdrop} 
          className={`w-full h-full object-cover opacity-40 transition-opacity duration-1000 ${isPlaying ? 'blur-sm' : ''}`} 
          alt="Video stream"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black opacity-60" />
        
        {!isPlaying && (
          <div className="z-10 bg-cyan-600 p-8 rounded-full animate-pulse">
            <svg className="w-16 h-16 fill-current text-white" viewBox="0 0 24 24">
              <path d="M8 5v14l11-7z" />
            </svg>
          </div>
        )}
      </div>

      {/* Top Header */}
      <div className={`absolute top-0 left-0 right-0 p-8 flex items-center justify-between transition-opacity duration-500 ${showControls ? 'opacity-100' : 'opacity-0'}`}>
        <div className="flex items-center space-x-4">
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors text-white">
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
          </button>
          <div>
            <h2 className="text-xl font-bold text-white">{content.title}</h2>
            <p className="text-sm text-gray-400">Streaming in 4K UHD</p>
          </div>
        </div>
      </div>

      {/* Bottom Controls */}
      <div className={`absolute bottom-0 left-0 right-0 p-8 bg-gradient-to-t from-black to-transparent transition-opacity duration-500 ${showControls ? 'opacity-100' : 'opacity-0'}`}>
        {/* Progress Bar */}
        <div className="group relative h-2 bg-gray-800 rounded-full mb-8 cursor-pointer overflow-hidden">
          <div 
            className="absolute top-0 left-0 h-full bg-cyan-500 transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
          <div 
            className="absolute h-full w-2 bg-white top-0 -ml-1 opacity-0 group-hover:opacity-100 transition-opacity"
            style={{ left: `${progress}%` }}
          />
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-8">
            <button onClick={() => setIsPlaying(!isPlaying)} className="text-white hover:text-cyan-400 transition-colors">
              {isPlaying ? (
                <svg className="w-8 h-8 fill-current" viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>
              ) : (
                <svg className="w-8 h-8 fill-current" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
              )}
            </button>
            <button onClick={() => setProgress(Math.max(0, progress - 5))} className="text-white hover:text-cyan-400">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12.066 11.2a1 1 0 000 1.6l5.334 4A1 1 0 0019 16V8a1 1 0 00-1.6-.8l-5.334 4zM4.066 11.2a1 1 0 000 1.6l5.334 4A1 1 0 0011 16V8a1 1 0 00-1.6-.8l-5.334 4z"/></svg>
            </button>
            <button onClick={() => setProgress(Math.min(100, progress + 5))} className="text-white hover:text-cyan-400">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11.934 12.8a1 1 0 000-1.6l-5.334-4A1 1 0 005 8v8a1 1 0 001.6.8l5.334-4zM19.934 12.8a1 1 0 000-1.6l-5.334-4A1 1 0 0013 8v8a1 1 0 001.6.8l5.334-4z"/></svg>
            </button>
            <div className="flex items-center space-x-3 group">
               <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z"/></svg>
               <input type="range" min="0" max="100" value={volume} onChange={(e) => setVolume(parseInt(e.target.value))} className="w-24 h-1 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-cyan-500" />
            </div>
          </div>
          <div className="flex items-center space-x-6">
            <span className="text-gray-400 font-mono text-sm">24:12 / {content.duration}</span>
            <button className="text-white hover:text-cyan-400">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4"/></svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoPlayer;
