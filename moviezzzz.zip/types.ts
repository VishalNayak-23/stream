
export type ContentType = 'movie' | 'tv-show';

export interface Content {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  backdrop: string;
  rating: number;
  year: number;
  duration: string;
  genres: string[];
  type: ContentType;
  isOriginal?: boolean;
  isKids?: boolean;
  trailerUrl?: string;
  cast: string[];
}

export interface User {
  id: string;
  name: string;
  email: string;
  password?: string;
  avatar: string;
}

export type ViewState = 'home' | 'movies' | 'tv-shows' | 'originals' | 'kids' | 'watchlist' | 'search';

export interface Toast {
  id: string;
  message: string;
  type: 'success' | 'info' | 'error';
}
