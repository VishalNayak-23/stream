
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Content, ViewState, User, Toast as ToastType } from './types';
import { MOCK_CONTENT } from './constants';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import MovieRow from './components/MovieRow';
import MovieDetails from './components/MovieDetails';
import MoviesPage from './components/MoviesPage';
import ContentGrid from './components/ContentGrid';
import Auth from './components/Auth';
import VideoPlayer from './components/VideoPlayer';
import Toast from './components/Toast';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('nebula_current_user');
    return saved ? JSON.parse(saved) : null;
  });

  const [currentView, setCurrentView] = useState<ViewState>('home');
  const [selectedContent, setSelectedContent] = useState<Content | null>(null);
  const [activePlayerContent, setActivePlayerContent] = useState<Content | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [toasts, setToasts] = useState<ToastType[]>([]);
  
  const [watchlist, setWatchlist] = useState<string[]>(() => {
    const saved = localStorage.getItem('nebula_watchlist');
    return saved ? JSON.parse(saved) : [];
  });

  const [continueWatching, setContinueWatching] = useState<Record<string, number>>(() => {
    const saved = localStorage.getItem('nebula_progress');
    return saved ? JSON.parse(saved) : {};
  });

  useEffect(() => {
    localStorage.setItem('nebula_watchlist', JSON.stringify(watchlist));
  }, [watchlist]);

  useEffect(() => {
    localStorage.setItem('nebula_progress', JSON.stringify(continueWatching));
  }, [continueWatching]);

  useEffect(() => {
    if (user) {
      localStorage.setItem('nebula_current_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('nebula_current_user');
    }
  }, [user]);

  const addToast = (message: string, type: ToastType['type'] = 'info') => {
    setToasts(prev => [...prev, { id: Date.now().toString(), message, type }]);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  const handleToggleWatchlist = useCallback((id: string) => {
    setWatchlist(prev => {
      const exists = prev.includes(id);
      addToast(exists ? 'Removed from Watchlist' : 'Added to Watchlist', exists ? 'error' : 'success');
      return exists ? prev.filter(i => i !== id) : [...prev, id];
    });
  }, []);

  const handleUpdateProgress = useCallback((id: string, progress: number) => {
    setContinueWatching(prev => ({ ...prev, [id]: progress }));
  }, []);

  const handleLogin = (newUser: User) => {
    setUser(newUser);
    addToast(`Welcome back, ${newUser.name}!`, 'success');
  };

  const handleLogout = () => {
    setUser(null);
    setCurrentView('home');
    addToast('Logged out successfully', 'info');
  };

  const filteredContent = useMemo(() => {
    const searchLower = searchQuery.toLowerCase();
    let base = MOCK_CONTENT;

    if (searchQuery) {
      base = base.filter(c => 
        c.title.toLowerCase().includes(searchLower) || 
        c.genres.some(g => g.toLowerCase().includes(searchLower))
      );
    }

    switch (currentView) {
      case 'movies': return base.filter(c => c.type === 'movie');
      case 'tv-shows': return base.filter(c => c.type === 'tv-show');
      case 'originals': return base.filter(c => c.isOriginal);
      case 'kids': return base.filter(c => c.isKids);
      case 'watchlist': return base.filter(c => watchlist.includes(c.id));
      default: return base;
    }
  }, [currentView, searchQuery, watchlist]);

  const watchingContent = MOCK_CONTENT.filter(c => Object.keys(continueWatching).includes(c.id));

  const renderContent = () => {
    if (!user) return <Auth onLogin={handleLogin} />;
    
    if (searchQuery) {
      return (
        <ContentGrid 
          title={`Results for "${searchQuery}"`}
          items={filteredContent}
          onSelect={setSelectedContent}
          watchlist={watchlist}
          onToggleWatchlist={handleToggleWatchlist}
        />
      );
    }

    if (currentView === 'movies') {
      return (
        <MoviesPage 
          items={MOCK_CONTENT}
          onSelect={setSelectedContent}
          watchlist={watchlist}
          onToggleWatchlist={handleToggleWatchlist}
        />
      );
    }

    if (currentView !== 'home') {
      return (
        <ContentGrid 
          title={currentView.replace('-', ' ').toUpperCase()}
          items={filteredContent}
          onSelect={setSelectedContent}
          watchlist={watchlist}
          onToggleWatchlist={handleToggleWatchlist}
        />
      );
    }

    return (
      <div className="space-y-12 pb-20">
        <Hero 
          content={MOCK_CONTENT[0]} 
          onSelect={setSelectedContent} 
        />
        
        {watchingContent.length > 0 && (
          <MovieRow 
            title="Continue Watching" 
            items={watchingContent} 
            onSelect={setSelectedContent}
            watchlist={watchlist}
            onToggleWatchlist={handleToggleWatchlist}
            progressMap={continueWatching}
          />
        )}

        <MovieRow 
          title="Trending Now" items={MOCK_CONTENT.slice(0, 6)} 
          onSelect={setSelectedContent} watchlist={watchlist}
          onToggleWatchlist={handleToggleWatchlist}
        />

        <MovieRow 
          title="Nebula Originals" items={MOCK_CONTENT.filter(c => c.isOriginal)} 
          onSelect={setSelectedContent} watchlist={watchlist}
          onToggleWatchlist={handleToggleWatchlist} isTall
        />
      </div>
    );
  };

  return (
    <div className="min-h-screen">
      <Navbar 
        currentView={currentView}
        onViewChange={(view) => { setCurrentView(view); setSearchQuery(''); }}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        user={user}
        onLogout={handleLogout}
      />
      
      <main className="pt-20">
        {renderContent()}
      </main>

      <Toast toasts={toasts} removeToast={removeToast} />

      {selectedContent && (
        <MovieDetails 
          content={selectedContent}
          onClose={() => setSelectedContent(null)}
          onPlay={() => { setActivePlayerContent(selectedContent); setSelectedContent(null); }}
          inWatchlist={watchlist.includes(selectedContent.id)}
          onToggleWatchlist={() => handleToggleWatchlist(selectedContent.id)}
        />
      )}

      {activePlayerContent && (
        <VideoPlayer 
          content={activePlayerContent}
          onClose={() => setActivePlayerContent(null)}
          initialProgress={continueWatching[activePlayerContent.id] || 0}
          onProgressUpdate={(p) => handleUpdateProgress(activePlayerContent.id, p)}
        />
      )}
    </div>
  );
};

export default App;
